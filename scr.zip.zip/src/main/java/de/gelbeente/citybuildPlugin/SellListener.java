package de.gelbeente.citybuildPlugin;

import de.gelbeente.citybuildPlugin.manager.SellManager;
import org.bukkit.event.Listener;

public class SellListener implements Listener {
    public SellListener(Main main, SellManager sellManager) {
    }
}

