package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.io.File;
import java.util.Arrays;
import java.util.UUID;

public class BattlePassManager {

    private final Main plugin;
    private final File file;
    private final YamlConfiguration config;

    public BattlePassManager(Main plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "battlepass.yml");
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public int getLevel(Player player) {
        return config.getInt(player.getUniqueId() + ".level", 1);
    }

    public int getXp(Player player) {
        return config.getInt(player.getUniqueId() + ".xp", 0);
    }

    public boolean hasPremium(Player player) {
        return config.getBoolean(player.getUniqueId() + ".premium", false);
    }

    public void setPremium(Player player, boolean active) {
        config.set(player.getUniqueId() + ".premium", active);
        save();
    }

    public void addXp(Player player, int amount) {
        int currentXp = getXp(player);
        int newXp = currentXp + amount;
        int level = getLevel(player);
        
        // Einfache Logik: 100 XP pro Level
        if (newXp >= 100) {
            newXp -= 100;
            level++;
            config.set(player.getUniqueId() + ".level", level);
            player.sendMessage("§b§lBATTLEPASS §8» §7Du bist nun Level §e" + level + "§7!");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
            giveReward(player, level);
        }
        
        config.set(player.getUniqueId() + ".xp", newXp);
        save();
    }

    private void giveReward(Player player, int level) {
        // Free Reward: 5x Diamant (Jedes Level)
        player.getInventory().addItem(new ItemStack(Material.DIAMOND, 5));
        player.sendMessage("§b§lBATTLEPASS §8» §aDu hast 5x Diamant erhalten (Free)!");

        // Premium Reward: 1x Crate Key (Jedes Level, wenn Premium)
        if (hasPremium(player)) {
            plugin.getCrateManager().addKeys(player.getUniqueId(), 1);
            player.sendMessage("§6§lPREMIUM §8» §aDu hast 1x Crate Key erhalten!");
        }
    }

    public void openMenu(Player player) {
        Inventory inv = Bukkit.createInventory(null, 54, "§d§lBattlePass");
        int level = getLevel(player);
        boolean premium = hasPremium(player);

        for (int i = 1; i <= 20; i++) { // 20 Level Beispiel
            int slot = i + 9; // Einfache GUI Anordnung
            if (slot >= 54) break;

            Material mat = (level >= i) ? Material.LIME_STAINED_GLASS_PANE : Material.RED_STAINED_GLASS_PANE;
            ItemStack item = new ItemStack(mat);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName("§eLevel " + i);
            
            String status = (level >= i) ? "§aFreigeschaltet" : "§cSperrt";
            String premiumStatus = premium ? "§aAktiv" : "§cInaktiv";
            
            meta.setLore(Arrays.asList(
                "§7Status: " + status,
                "§7Free Reward: §f5x Diamant",
                "§6Premium Reward: §f1x Crate Key",
                " ",
                "§7Dein Premium: " + premiumStatus
            ));
            item.setItemMeta(meta);
            inv.setItem(slot, item);
        }
        
        // Info / Kauf Button
        ItemStack info = new ItemStack(Material.NETHER_STAR);
        ItemMeta infoMeta = info.getItemMeta();
        infoMeta.setDisplayName("§6§lPremium Pass kaufen");
        infoMeta.setLore(Arrays.asList(
            "§7Kosten: §e500 Gems",
            "§7Klicke zum Kaufen"
        ));
        info.setItemMeta(infoMeta);
        inv.setItem(4, info);

        player.openInventory(inv);
    }

    public void buyPremium(Player player) {
        if (hasPremium(player)) {
            player.sendMessage("§cDu hast den Pass schon!");
            return;
        }
        if (plugin.getEconomyManager().getGems(player.getUniqueId()) >= 500) {
            plugin.getEconomyManager().removeGems(player.getUniqueId(), 500);
            setPremium(player, true);
            player.sendMessage("§aPremium Pass gekauft!");
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 1);

            // Nachträgliche Belohnungen für bereits erreichte Level geben
            int level = getLevel(player);
            int keysToGive = level - 1; // Für jedes Level-Up (ab Level 2)
            
            if (keysToGive > 0) {
                plugin.getCrateManager().addKeys(player.getUniqueId(), keysToGive);
                player.sendMessage("§6§lPREMIUM §8» §aDu hast " + keysToGive + "x Crate Keys nachträglich erhalten!");
            }

            player.closeInventory();
        } else {
            player.sendMessage("§cNicht genügend Gems (500 benötigt).");
        }
    }

    private void save() {
        try { config.save(file); } catch (Exception e) {}
    }
}