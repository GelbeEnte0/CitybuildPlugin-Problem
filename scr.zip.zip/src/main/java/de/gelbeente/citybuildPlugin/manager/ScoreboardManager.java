package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class ScoreboardManager {

    private final Main plugin;

    public ScoreboardManager(Main plugin) {
        this.plugin = plugin;
    }



    public void startScoreboardTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    updateScoreboard(player);
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public void updateScoreboard(Player player) {
        Scoreboard board = player.getScoreboard();
        if (board == null || board.getObjective("citybuild") == null) {
            board = Bukkit.getScoreboardManager().getNewScoreboard();
            player.setScoreboard(board);
        }

        Objective obj = board.getObjective("citybuild");
        if (obj == null) {
            obj = board.registerNewObjective("citybuild", "dummy", ChatColor.GOLD + "" + ChatColor.BOLD + " CityBuild ");
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        }

        double balance = plugin.getEconomyManager().getBalance(player.getUniqueId());
        String rank = plugin.getRankManager().getRankPrefix(player);

        setScore(board, ChatColor.GRAY + " ", 7);
        setScore(board, ChatColor.YELLOW + "Rank:", 6);
        setScore(board, ChatColor.WHITE + rank, 5);
        setScore(board, ChatColor.GRAY + "  ", 4);
        setScore(board, ChatColor.YELLOW + "Geld:", 3);
        setScore(board, ChatColor.WHITE + String.format("%.2f", balance) + "$", 2);
        setScore(board, ChatColor.GRAY + "   ", 1);
        setScore(board, ChatColor.YELLOW + "Enten.City.net", 0);
    }

    private void setScore(Scoreboard board, String text, int score) {
        Team team = board.getTeam("line" + score);
        if (team == null) {
            team = board.registerNewTeam("line" + score);
            team.addEntry(ChatColor.values()[score].toString());
        }
        
        team.setPrefix(text);
        Objective obj = board.getObjective("citybuild");
        obj.getScore(ChatColor.values()[score].toString()).setScore(score);
    }
}
