package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.Arrays;

public class ShopManager {

    public final String MAIN_TITLE = "§6§lShop §8» §7Kategorien";
    public final String ORE_TITLE = "§b§lShop §8» §7Erze";

    public ShopManager(Main main) {
    }

    // 1. Hauptmenü öffnen
    public void openGui(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, MAIN_TITLE);

        inv.setItem(11, createItem(Material.DIAMOND_ORE, "§b§lErze", "§7Klicke zum Öffnen"));
        inv.setItem(13, createItem(Material.COOKED_BEEF, "§e§lEssen", "§7Klicke zum Öffnen"));
        inv.setItem(15, createItem(Material.GRASS_BLOCK, "§a§lBlöcke", "§7Klicke zum Öffnen"));

        player.openInventory(inv);
    }

    // 2. Kategorie: Erze
    public void openOreCategory(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, ORE_TITLE);

        // Items mit Preis im Lore (Beschreibung)
        inv.setItem(10, createItem(Material.DIAMOND, "§bDiamant", "§7Preis: §a100$"));
        inv.setItem(12, createItem(Material.GOLD_INGOT, "§eGoldbarren", "§7Preis: §a50$"));
        inv.setItem(14, createItem(Material.IRON_INGOT, "§fEisenbarren", "§7Preis: §a20$"));

        inv.setItem(26, createItem(Material.BARRIER, "§cZurück", ""));
        player.openInventory(inv);
    }

    // 3. Mengen-Auswahl (Wird geöffnet wenn man auf ein Item klickt)
    public void openAmountSelect(Player player, Material mat, double price) {
        Inventory inv = Bukkit.createInventory(null, 9, "§8Kaufen: §b" + mat.name() + ":" + price);

        inv.setItem(2, createItem(mat, "§a1x kaufen", "§7Preis: §e" + price + "$"));
        inv.setItem(4, createItem(mat, "§a16x kaufen", "§7Preis: §e" + (price * 16) + "$"));
        inv.setItem(6, createItem(mat, "§a64x kaufen", "§7Preis: §e" + (price * 64) + "$"));

        player.openInventory(inv);
    }

    private ItemStack createItem(Material mat, String name, String lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(Arrays.asList(lore));
        item.setItemMeta(meta);
        return item;
    }

    public void save() {
    }

    public void openShop(Player sender) {

    }
}
