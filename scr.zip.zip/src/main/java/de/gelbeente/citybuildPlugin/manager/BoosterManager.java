package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;

import java.util.HashMap;
import java.util.Map;

public class BoosterManager {

    public enum BoosterType {
        FLY, MONEY, DROP
    }

    private final Main plugin;
    private final Map<BoosterType, Long> activeBoosters = new HashMap<>();

    public BoosterManager(Main plugin) {
        this.plugin = plugin;
    }

    public void activateBooster(BoosterType type, int minutes) {
        long endTime = System.currentTimeMillis() + (minutes * 60000L);
        // Wenn schon aktiv, Zeit addieren
        if (isActive(type)) {
            endTime = activeBoosters.get(type) + (minutes * 60000L);
        }
        activeBoosters.put(type, endTime);
    }

    public boolean isActive(BoosterType type) {
        if (!activeBoosters.containsKey(type)) return false;
        if (System.currentTimeMillis() > activeBoosters.get(type)) {
            activeBoosters.remove(type);
            return false;
        }
        return true;
    }
    
    public long getRemainingTime(BoosterType type) {
        return isActive(type) ? (activeBoosters.get(type) - System.currentTimeMillis()) / 1000 : 0;
    }
}