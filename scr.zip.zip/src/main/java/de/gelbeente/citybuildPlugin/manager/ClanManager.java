package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class ClanManager {

    private final Main plugin;
    private final File file;
    private final YamlConfiguration config;
    private final HashMap<Player, String> invites = new HashMap<>();

    public ClanManager(Main plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "clans.yml");
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public boolean exists(String name) {
        return config.contains("clans." + name);
    }

    public void createClan(Player owner, String name) {
        config.set("clans." + name + ".owner", owner.getUniqueId().toString());
        List<String> members = new ArrayList<>();
        members.add(owner.getUniqueId().toString());
        config.set("clans." + name + ".members", members);
        config.set("players." + owner.getUniqueId(), name);
        save();
    }

    public void deleteClan(String name) {
        List<String> members = config.getStringList("clans." + name + ".members");
        for (String memberUUID : members) {
            config.set("players." + memberUUID, null);
        }
        config.set("clans." + name, null);
        save();
    }

    public String getClan(Player player) {
        return config.getString("players." + player.getUniqueId());
    }

    public boolean isOwner(Player player, String clanName) {
        String ownerUUID = config.getString("clans." + clanName + ".owner");
        return player.getUniqueId().toString().equals(ownerUUID);
    }

    public void invitePlayer(Player target, String clanName) {
        invites.put(target, clanName);
    }

    public boolean hasInvite(Player player) {
        return invites.containsKey(player);
    }

    public void acceptInvite(Player player) {
        if (!hasInvite(player)) return;
        String clanName = invites.get(player);
        
        List<String> members = config.getStringList("clans." + clanName + ".members");
        members.add(player.getUniqueId().toString());
        config.set("clans." + clanName + ".members", members);
        config.set("players." + player.getUniqueId(), clanName);
        
        invites.remove(player);
        save();
    }

    public void leaveClan(Player player) {
        String clanName = getClan(player);
        if (clanName == null) return;

        List<String> members = config.getStringList("clans." + clanName + ".members");
        members.remove(player.getUniqueId().toString());
        config.set("clans." + clanName + ".members", members);
        config.set("players." + player.getUniqueId(), null);
        save();
    }

    private void save() { try { config.save(file); } catch (Exception e) {} }
}