package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import java.util.HashMap;
import java.util.Map;

public class TradeManager {

    private final Map<Player, Player> tradeRequests = new HashMap<>();
    private final Map<Player, Inventory> activeTrades = new HashMap<>();

    public TradeManager(Main main) {

    }

    public TradeManager() {

    }

    public void sendRequest(Player sender, Player target) {
        tradeRequests.put(target, sender);
    }

    public Player getRequestSender(Player target) {
        return tradeRequests.get(target);
    }

    public void removeRequest(Player target) {
        tradeRequests.remove(target);
    }

    public void startTrade(Player p1, Player p2) {
        // Wir erstellen kein Inventar hier, das macht der Listener/Command, 
        // wir merken uns nur, dass sie traden.
        activeTrades.put(p1, null);
        activeTrades.put(p2, null);
    }
    
    public boolean isTrading(Player p) {
        return activeTrades.containsKey(p);
    }
    
    public void stopTrade(Player p) {
        activeTrades.remove(p);
    }
}