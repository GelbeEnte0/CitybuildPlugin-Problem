package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.Arrays;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class CrateManager {

    private final Main plugin;
    private final List<CrateItem> rewards = new ArrayList<>();
    private final Random random = new Random();
    
    private File file;
    private FileConfiguration config;

    public CrateManager(Main plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "keys.yml");
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.config = YamlConfiguration.loadConfiguration(file);
        loadRewards();
    }

    public void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // --- KEY SYSTEM (DIGITAL) ---

    public int getKeys(UUID uuid) {
        return config.getInt(uuid.toString(), 0);
    }

    public void setKeys(UUID uuid, int amount) {
        config.set(uuid.toString(), amount);
        save();
    }

    public void addKeys(UUID uuid, int amount) {
        setKeys(uuid, getKeys(uuid) + amount);
    }

    public void removeKeys(UUID uuid, int amount) {
        setKeys(uuid, Math.max(0, getKeys(uuid) - amount));
    }

    private void loadRewards() {
        // Hier fügen wir Items hinzu: Material, Name, Chance (Gewichtung), Rarität
        rewards.add(new CrateItem(Material.DIRT, "§7Dreck", 50, Rarity.COMMON));
        rewards.add(new CrateItem(Material.OAK_LOG, "§7Holz", 40, Rarity.COMMON));
        rewards.add(new CrateItem(Material.IRON_INGOT, "§fEisenbarren", 30, Rarity.RARE));
        rewards.add(new CrateItem(Material.GOLD_INGOT, "§6Goldbarren", 25, Rarity.RARE));
        rewards.add(new CrateItem(Material.DIAMOND, "§bDiamant", 15, Rarity.EPIC));
        rewards.add(new CrateItem(Material.EMERALD, "§aSmaragd", 15, Rarity.EPIC));
        rewards.add(new CrateItem(Material.BEACON, "§b§lBEACON", 5, Rarity.JACKPOT));
        rewards.add(new CrateItem(Material.NETHER_STAR, "§b§lNETHER STAR", 5, Rarity.JACKPOT));
        rewards.add(new CrateItem(Material.DRAGON_EGG, "§5§lDRACHENEI", 1, Rarity.MEGA_JACKPOT));
        rewards.add(new CrateItem(Material.ELYTRA, "§d§lELYTRA", 1, Rarity.MEGA_JACKPOT));
        
        // NEUE ITEMS HIER HINZUFÜGEN:
        // Format: Material, Name, Wahrscheinlichkeit (höher = öfter), Rarität
        rewards.add(new CrateItem(Material.GOLDEN_APPLE, "§6Goldapfel", 20, Rarity.RARE));
        rewards.add(new CrateItem(Material.NETHERITE_INGOT, "§8Netherite Barren", 5, Rarity.JACKPOT));
    }

    public void openCrate(Player player) {
        // Checken ob Spieler Keys hat
        int keys = getKeys(player.getUniqueId());
        if (keys <= 0) {
            player.sendMessage("§cDu hast keine Crate Keys! Besorge dir welche im Shop oder BattlePass.");
            return;
        }

        // Key abziehen
        removeKeys(player.getUniqueId(), 1);
        player.sendMessage("§aÖffne Crate... (Verbleibende Keys: §e" + (keys - 1) + "§a)");

        Inventory inv = Bukkit.createInventory(null, 27, "§8§lÖffne Kiste...");
        player.openInventory(inv);

        // Hintergrund (Glas)
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        meta.setDisplayName(" ");
        glass.setItemMeta(meta);

        for (int i = 0; i < 27; i++) {
            inv.setItem(i, glass);
        }
        
        // Zeiger (Gewinnlinie)
        inv.setItem(4, new ItemStack(Material.HOPPER));
        inv.setItem(22, new ItemStack(Material.HOPPER));

        // Animation starten
        startSpinning(player, inv, 2.0, 0);
    }

    private void startSpinning(Player player, Inventory inv, double delay, int itemsGenerated) {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (int i = 9; i < 17; i++) inv.setItem(i, inv.getItem(i + 1));
                
                CrateItem next = getRandomReward();
                inv.setItem(17, next.createItemStack());
                player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.5f);

                if (itemsGenerated >= 40) { // Ende erreicht
                    ItemStack winItem = inv.getItem(13);
                    CrateItem reward = getRewardByStack(winItem);
                    if (reward != null) giveReward(player, reward);
                    return;
                }

                // Rekursiver Aufruf mit mehr Delay (langsamer werden)
                double newDelay = delay;
                if (itemsGenerated > 30) newDelay += 1.0;
                if (itemsGenerated > 35) newDelay += 2.0;
                
                startSpinning(player, inv, newDelay, itemsGenerated + 1);
            }
        }.runTaskLater(plugin, (long) delay);
    }

    private void giveReward(Player player, CrateItem reward) {
        player.getInventory().addItem(reward.createItemStack());
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
        player.sendMessage("§aDu hast " + reward.name + " §agewonnen!");

        if (reward.rarity == Rarity.JACKPOT || reward.rarity == Rarity.MEGA_JACKPOT) {
            Bukkit.broadcastMessage("§8§m---------------------------------------");
            Bukkit.broadcastMessage("§6§l" + reward.rarity.name().replace("_", " ") + " §8» §e" + player.getName());
            Bukkit.broadcastMessage("§7hat gerade aus der Kiste " + reward.name + " §7gezogen!");
            Bukkit.broadcastMessage("§8§m---------------------------------------");
            for(Player all : Bukkit.getOnlinePlayers()) all.playSound(all.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1, 1);
        }
    }

    private CrateItem getRandomReward() {
        int totalWeight = rewards.stream().mapToInt(r -> r.chance).sum();
        int randomValue = random.nextInt(totalWeight);
        int currentWeight = 0;
        for (CrateItem item : rewards) {
            currentWeight += item.chance;
            if (randomValue < currentWeight) return item;
        }
        return rewards.get(0);
    }

    private CrateItem getRewardByStack(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        String name = stack.getItemMeta().getDisplayName();
        return rewards.stream().filter(r -> r.name.equals(name)).findFirst().orElse(null);
    }

    private class CrateItem {
        Material material;
        String name;
        int chance;
        Rarity rarity;

        public CrateItem(Material material, String name, int chance, Rarity rarity) {
            this.material = material;
            this.name = name;
            this.chance = chance;
            this.rarity = rarity;
        }

        public ItemStack createItemStack() {
            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(name);
            meta.setLore(Arrays.asList(rarity.displayName));
            item.setItemMeta(meta);
            return item;
        }
    }

    public enum Rarity {
        COMMON("§7Gewöhnlich"), RARE("§9Selten"), EPIC("§5Episch"), JACKPOT("§6§lJACKPOT"), MEGA_JACKPOT("§4§lMEGA JACKPOT");
        final String displayName;
        Rarity(String displayName) { this.displayName = displayName; }
    }
}