package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PerkManager {

    public enum Perk {
        NO_HUNGER("§6Kein Hunger", 1000),
        NO_FALL("§bKein Fallschaden", 1500),
        HASTE("§eEile (Haste)", 2500),
        SPEED("§fGeschwindigkeit", 2000),
        KEEP_XP("§aBehalte XP", 5000);

        public final String displayName;
        public final int cost;

        Perk(String displayName, int cost) {
            this.displayName = displayName;
            this.cost = cost;
        }
    }

    private final Main plugin;
    private final File file;
    private final YamlConfiguration config;

    public PerkManager(Main plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "perks.yml");
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public boolean hasPerk(Player player, Perk perk) {
        List<String> perks = config.getStringList(player.getUniqueId().toString());
        return perks.contains(perk.name());
    }

    public void addPerk(Player player, Perk perk) {
        List<String> perks = config.getStringList(player.getUniqueId().toString());
        if (!perks.contains(perk.name())) {
            perks.add(perk.name());
            config.set(player.getUniqueId().toString(), perks);
            save();
        }
    }

    public void removePerk(Player player, Perk perk) {
        List<String> perks = config.getStringList(player.getUniqueId().toString());
        if (perks.contains(perk.name())) {
            perks.remove(perk.name());
            config.set(player.getUniqueId().toString(), perks);
            save();
        }
    }

    private void save() {
        try { config.save(file); } catch (Exception e) { e.printStackTrace(); }
    }
}