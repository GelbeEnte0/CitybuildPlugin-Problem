package de.gelbeente.citybuildPlugin.manager;

import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class EnchantManager {

    public static final String TIMBER = "§6Timber I";
    public static final String BLAST_3x3 = "§cBlast I (3x3)";
    public static final String GIANT_5x5 = "§4Giant I (5x5)";

    public ItemStack addEnchant(ItemStack item, String enchantName) {
        if (item == null || !item.getType().isItem()) return item;
        
        ItemMeta meta = item.getItemMeta();
        List<String> lore = meta.hasLore() ? meta.getLore() : new ArrayList<>();
        
        // Prüfen ob schon drauf
        if (lore.contains(enchantName)) return item;

        lore.add(enchantName);
        meta.setLore(lore);
        item.setItemMeta(meta);
        
        return item;
    }

    public boolean hasEnchant(ItemStack item, String enchantName) {
        if (item == null || !item.hasItemMeta()) return false;
        if (!item.getItemMeta().hasLore()) return false;
        
        // Wir entfernen Farbcodes für den Check, um sicher zu gehen, oder checken exakt
        return item.getItemMeta().getLore().contains(enchantName);
    }

    // Entfernt "Timber" wenn man z.B. 3x3 draufmacht (optional, hier erlauben wir beides)
}