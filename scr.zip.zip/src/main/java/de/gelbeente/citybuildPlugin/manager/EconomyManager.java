package de.gelbeente.citybuildPlugin.manager;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import de.gelbeente.citybuildPlugin.Main;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class EconomyManager {

    private final Main plugin;
    private File file;
    private FileConfiguration config;

    public EconomyManager(Main plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "money.yml");
        if (!file.exists()) {
            try {
                file.getParentFile().mkdirs();
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public double getBalance(UUID uuid) {
        return config.getDouble(uuid.toString() + ".balance", 0.0);
    }

    public void setBalance(UUID uuid, double amount) {
        config.set(uuid.toString() + ".balance", amount);
        save();
    }

    public void addMoney(UUID uuid, double amount) {
        setBalance(uuid, getBalance(uuid) + amount);
    }

    public void removeMoney(UUID uuid, double amount) {
        setBalance(uuid, getBalance(uuid) - amount);
    }

    public double getBankBalance(UUID uuid) {
        return config.getDouble(uuid.toString() + ".bank", 0.0);
    }

    public void setBankBalance(UUID uuid, double amount) {
        config.set(uuid.toString() + ".bank", amount);
        save();
    }
    
    public void deposit(UUID uuid, double amount) {
        if (getBalance(uuid) >= amount) {
            removeMoney(uuid, amount);
            setBankBalance(uuid, getBankBalance(uuid) + amount);
        }
    }

    public void withdraw(UUID uuid, double amount) {
        if (getBankBalance(uuid) >= amount) {
            setBankBalance(uuid, getBankBalance(uuid) - amount);
            addMoney(uuid, amount);
        }
    }

    // --- GEM SYSTEM ---

    public long getGems(UUID uuid) {
        return config.getLong(uuid.toString() + ".gems", 0);
    }

    public void setGems(UUID uuid, long amount) {
        config.set(uuid.toString() + ".gems", amount);
        save();
    }

    public void addGems(UUID uuid, long amount) {
        setGems(uuid, getGems(uuid) + amount);
    }

    public void removeGems(UUID uuid, long amount) {
        setGems(uuid, getGems(uuid) - amount);
    }
}
