package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

public class SellManager {

    private final Main plugin;
    private final Map<Material, Double> basePrices = new HashMap<>();
    public final String GUI_TITLE = "§6§lVerkaufen §7(Enten.City)";

    public SellManager(Main plugin) {
        this.plugin = plugin;
        setupPrices();
    }

    private void setupPrices() {
        basePrices.put(Material.DIAMOND, 100.0);
        basePrices.put(Material.GOLD_INGOT, 50.0);
        basePrices.put(Material.IRON_INGOT, 20.0);
        basePrices.put(Material.EMERALD, 150.0);
        basePrices.put(Material.COAL, 5.0);
        basePrices.put(Material.REDSTONE, 8.0);
        basePrices.put(Material.STONE, 1.0);
        basePrices.put(Material.COBBLESTONE, 0.5);
        basePrices.put(Material.OAK_LOG, 4.0);
        basePrices.put(Material.WHEAT, 3.0);
    }

    // Öffnet das Verkaufs-Inventar für den Spieler
    public void openSellGUI(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, GUI_TITLE);
        player.openInventory(inv);
    }

    public double getPrice(Material material) {
        if (!basePrices.containsKey(material)) return 0.0;
        double base = basePrices.get(material);

        if (plugin.getMarketManager() != null) {
            Material hypeMat = plugin.getMarketManager().getCurrentHypeMaterial();
            if (hypeMat == material) {
                return base * plugin.getMarketManager().getCurrentMultiplier();
            }
        }
        return base;
    }
}