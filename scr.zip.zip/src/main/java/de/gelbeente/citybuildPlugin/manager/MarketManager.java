package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;

public class MarketManager {

    private final Main plugin;
    private Material currentHypeMaterial = null;
    private double currentMultiplier = 1.0;
    private String currentEventName = "Stabil";

    // Items, die in der Börse landen können
    private final Material[] marketItems = {
            Material.DIAMOND, Material.GOLD_INGOT, Material.IRON_INGOT,
            Material.EMERALD, Material.COAL, Material.REDSTONE,
            Material.WHEAT, Material.STONE, Material.OAK_LOG
    };

    public MarketManager(Main plugin) {
        this.plugin = plugin;
        startMarketTask();
    }

    private void startMarketTask() {
        // Alle 10 Minuten (12000 Ticks) ändert sich der Markt
        new BukkitRunnable() {
            @Override
            public void run() {
                changeMarket();
            }
        }.runTaskTimer(plugin, 200L, 12000L); // Startet nach 10 sek, dann alle 10 min
    }

    private void changeMarket() {
        Random random = new Random();
        currentHypeMaterial = marketItems[random.nextInt(marketItems.length)];
        
        // Entscheiden ob Hype (gut) oder Crash (schlecht)
        boolean isHype = random.nextBoolean();

        if (isHype) {
            currentMultiplier = 2.0 + (random.nextDouble() * 1.5); // Zwischen 2.0x und 3.5x
            currentEventName = "§a§lHYPE";
            Bukkit.broadcastMessage("§8§m---------------------------------------");
            Bukkit.broadcastMessage("§6§lBÖRSE §8» §aDie Nachfrage nach §e" + currentHypeMaterial.name() + " §aist explodiert!");
            Bukkit.broadcastMessage("§8» §7Verkaufspreis: §a" + String.format("%.1f", currentMultiplier) + "x Multiplikator");
            Bukkit.broadcastMessage("§8§m---------------------------------------");
        } else {
            currentMultiplier = 0.3 + (random.nextDouble() * 0.4); // Zwischen 0.3x und 0.7x
            currentEventName = "§c§lCRASH";
            Bukkit.broadcastMessage("§8§m---------------------------------------");
            Bukkit.broadcastMessage("§6§lBÖRSE §8» §cDer Markt für §e" + currentHypeMaterial.name() + " §cist eingebrochen!");
            Bukkit.broadcastMessage("§8» §7Verkaufspreis: §c" + String.format("%.1f", currentMultiplier) + "x Multiplikator");
            Bukkit.broadcastMessage("§8§m---------------------------------------");
        }

        // Sound für alle
        for (Player all : Bukkit.getOnlinePlayers()) {
            all.playSound(all.getLocation(), isHype ? Sound.ENTITY_PLAYER_LEVELUP : Sound.ENTITY_VILLAGER_NO, 1, 1);
        }
    }

    public Material getCurrentHypeMaterial() {
        return currentHypeMaterial;
    }

    public double getCurrentMultiplier() {
        return currentMultiplier;
    }
}