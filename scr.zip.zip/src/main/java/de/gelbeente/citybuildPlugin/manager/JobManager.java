package de.gelbeente.citybuildPlugin.manager;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class JobManager {

    public enum Job {
        NONE, MINER, LUMBERJACK, DIGGER
    }

    private final Main plugin;
    private final File file;
    private final Map<UUID, Job> playerJobs = new HashMap<>();

    public JobManager(Main plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "jobs.yml");
        load();
    }

    public void setJob(Player player, Job job) {
        playerJobs.put(player.getUniqueId(), job);
        save();
    }

    public Job getJob(Player player) {
        return playerJobs.getOrDefault(player.getUniqueId(), Job.NONE);
    }

    private void save() {
        YamlConfiguration config = new YamlConfiguration();
        playerJobs.forEach((uuid, job) -> config.set(uuid.toString(), job.name()));
        try { config.save(file); } catch (Exception e) { e.printStackTrace(); }
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        for (String key : config.getKeys(false)) {
            try {
                playerJobs.put(UUID.fromString(key), Job.valueOf(config.getString(key)));
            } catch (Exception ignored) {}
        }
    }
}