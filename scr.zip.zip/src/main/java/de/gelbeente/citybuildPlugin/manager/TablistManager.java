package de.gelbeente.citybuildPlugin.manager;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class TablistManager implements Listener {

    public void updateTablist(Player player) {
        // 1. Header & Footer (Hellblau & Lila/Pink)
        player.setPlayerListHeaderFooter(
                "\n §b§lENTEN.CITY.NET §r§7- §fDein Citybuild \n §7Online: §a" + Bukkit.getOnlinePlayers().size() + " \n",
                "\n §dViel Spaß beim Bauen, §e" + player.getName() + "§d! \n §bPlugin by GelbeEnte \n"
        );

        // 2. Scoreboard & Teams für die Ränge
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();

        // Alle Teams mit Sortierung und Farben erstellen
        Team owner = getTeam(sb, "001Owner", "§4§lOwner §8| §f");
        Team admin = getTeam(sb, "002Admin", "§c§lAdmin §8| §f");
        Team mod = getTeam(sb, "003Mod", "§9§lMod §8| §f");
        Team sup = getTeam(sb, "004Sup", "§b§lSup §8| §f");
        Team creator = getTeam(sb, "005creator", "§5§lCreator §8| §f");
        Team spieler = getTeam(sb, "006Spieler", "§a§lSpieler §8| §f");

        // Spieler basierend auf Permissions zuordnen
        if (player.hasPermission("group.owner")) {
            owner.addEntry(player.getName());
        } else if (player.hasPermission("group.admin")) {
            admin.addEntry(player.getName());
        } else if (player.hasPermission("group.mod")) {
            mod.addEntry(player.getName());
        } else if (player.hasPermission("group.supporter")) {
            sup.addEntry(player.getName());
        } else if (player.hasPermission("group.creator")) {
            creator.addEntry(player.getName());
        } else {
            spieler.addEntry(player.getName());
        }

        player.setScoreboard(sb);
    }

    private Team getTeam(Scoreboard sb, String teamName, String prefix) {
        Team team = sb.getTeam(teamName);
        if (team == null) team = sb.registerNewTeam(teamName);
        team.setPrefix(prefix);
        return team;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Für alle Spieler aktualisieren, wenn jemand joint
        for (Player all : Bukkit.getOnlinePlayers()) {
            updateTablist(all);
        }
    }
}