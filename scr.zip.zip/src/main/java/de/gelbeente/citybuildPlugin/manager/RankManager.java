package de.gelbeente.citybuildPlugin.manager;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class RankManager {

    // Ermittelt den Rang-Namen für das Scoreboard oder den Chat
    public String getRankName(Player player) {
        if (player.hasPermission("citybuild.rank.owner")) {
            return "Owner";
        } else if (player.hasPermission("citybuild.rank.admin")) {
            return "Admin";
        } else if (player.hasPermission("citybuild.rank.creator")) {
            return "Creator";
        } else if (player.hasPermission("citybuild.rank.premium")) {
            return "Premium";
        } else {
            return "Spieler";
        }
    }

    // Ermittelt den farbigen Prefix (für Tablist oder Chat)
    public String getRankPrefix(Player player) {
        if (player.hasPermission("citybuild.rank.owner")) {
            return ChatColor.DARK_RED + "Owner";
        } else if (player.hasPermission("citybuild.rank.admin")) {
            return ChatColor.RED + "Admin";
        } else if (player.hasPermission("citybuild.rank.creator")) {
            return ChatColor.DARK_PURPLE + "Creator";
        } else if (player.hasPermission("citybuild.rank.premium")) {
            return ChatColor.GOLD + "Premium";
        } else {
            return ChatColor.GRAY + "Spieler";
        }
    }
    
    public String getChatColor(Player player) {
        return player.hasPermission("citybuild.chat.color") ? "§f" : "§7";
    }
}