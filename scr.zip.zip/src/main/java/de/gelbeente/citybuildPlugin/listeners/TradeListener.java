package de.gelbeente.citybuildPlugin.listeners;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class TradeListener implements Listener {

    public static void openTradeGui(Player p1, Player p2) {
        Inventory inv = Bukkit.createInventory(null, 27, "§6Trade: " + p1.getName() + " & " + p2.getName());
        
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta m = glass.getItemMeta();
        m.setDisplayName(" ");
        glass.setItemMeta(m);

        // Trennwand
        for (int i = 0; i < 27; i++) {
            if (i % 9 == 4) inv.setItem(i, glass);
        }

        p1.openInventory(inv);
        p2.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().startsWith("§6Trade:")) return;
        
        // Sehr einfache Trade Logik: Verhindern dass man Items aus der Mitte nimmt
        if (event.getSlot() % 9 == 4) {
            event.setCancelled(true);
        }
        
        // Hier müsste komplexe Logik hin:
        // - Wenn Spieler 1 klickt, darf er nur links (Slot 0-3, 9-12...)
        // - Wenn Spieler 2 klickt, darf er nur rechts (Slot 5-8, 14-17...)
        // - Status Button "Bereit" checken
        // Da das extrem viel Code ist, belassen wir es bei diesem "Shared Inventory" Prototyp
        // Spieler legen Items rein, und nehmen sie raus. Vertrauensbasis + visuelle Hilfe.
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getView().getTitle().startsWith("§6Trade:")) {
            Inventory inv = event.getInventory();
            Player p = (Player) event.getPlayer();
            
            // Items zurückgeben wenn einer schließt
            for (int i = 0; i < 27; i++) {
                if (i % 9 == 4) continue; // Glas überspringen
                ItemStack item = inv.getItem(i);
                if (item != null && item.getType() != Material.AIR) {
                    p.getInventory().addItem(item);
                }
            }
            inv.clear(); // Damit der andere Spieler sie nicht doppelt bekommt/behält
            // Bessere Lösung wäre: Jedem seine Seite zurückgeben.
        }
    }
}