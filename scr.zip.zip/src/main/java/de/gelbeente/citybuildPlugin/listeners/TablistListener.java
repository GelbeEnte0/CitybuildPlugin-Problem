package de.gelbeente.citybuildPlugin.listeners;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

class TablistManager implements Listener {

    // Diese Methode setzt die Optik und die Ränge
    public void updateTablist(Player player) {
        // 1. Header & Footer (Hellblau §b & Lila/Pink §d)
        player.setPlayerListHeaderFooter(
                "\n §b§lENTEN.CITY.NET §r§7- §fDein Citybuild \n §7Online: §a" + Bukkit.getOnlinePlayers().size() + " §8/ §2100 \n",
                "\n §dViel Spaß beim Bauen, §e" + player.getName() + "§d! \n §bPlugin by GelbeEnte \n"
        );

        // 2. Scoreboard für die Ränge (Präfixe & Sortierung)
        Scoreboard sb = Bukkit.getScoreboardManager().getMainScoreboard();

        // Teams erstellen/laden (001-006 sorgt für die richtige Reihenfolge von oben nach unten)
        Team owner = getOrCreateTeam(sb, "001Owner", "§4Owner §8| §f");
        Team admin = getOrCreateTeam(sb, "002Admin", "§cAdmin §8| §f");
        Team mod = getOrCreateTeam(sb, "003Mod", "§9Mod §8| §f");
        Team sup = getOrCreateTeam(sb, "004Sup", "§bSup §8| §f");
        Team content = getOrCreateTeam(sb, "005Content", "§eCreator §8| §f");
        Team spieler = getOrCreateTeam(sb, "006Spieler", "§aSpieler §8| §f");

        // Rang-Zuweisung basierend auf Permissions (LuckPerms kompatibel)
        if (player.hasPermission("group.owner")) {
            owner.addEntry(player.getName());
        } else if (player.hasPermission("group.admin")) {
            admin.addEntry(player.getName());
        } else if (player.hasPermission("group.mod")) {
            mod.addEntry(player.getName());
        } else if (player.hasPermission("group.supporter")) {
            sup.addEntry(player.getName());
        } else if (player.hasPermission("group.creator")) {
            content.addEntry(player.getName());
        } else {
            spieler.addEntry(player.getName());
        }

        player.setScoreboard(sb);
    }

    // Hilfsmethode für die Teams
    private Team getOrCreateTeam(Scoreboard sb, String teamName, String prefix) {
        Team team = sb.getTeam(teamName);
        if (team == null) {
            team = sb.registerNewTeam(teamName);
        }
        team.setPrefix(prefix);
        return team;
    }

    // LISTENER: Wird aufgerufen, wenn jemand den Server betritt
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Wenn jemand joint, müssen wir die Tablist für JEDEN aktualisieren (wegen der Online-Zahl)
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugins()[0], () -> {
            for (Player all : Bukkit.getOnlinePlayers()) {
                updateTablist(all);
            }
        }, 1L); // 1 Tick Verzögerung, damit die Online-Zahl stimmt
    }

    // LISTENER: Wird aufgerufen, wenn jemand den Server verlässt
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Auch beim Verlassen aktualisieren (Online-Zahl sinkt)
        Bukkit.getScheduler().runTaskLater(Bukkit.getPluginManager().getPlugins()[0], () -> {
            for (Player all : Bukkit.getOnlinePlayers()) {
                updateTablist(all);
            }
        }, 1L);
    }
}
