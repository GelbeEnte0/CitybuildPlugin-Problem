package de.gelbeente.citybuildPlugin.listeners;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.RankManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class ChatListener implements Listener {
    private final Main plugin;
    private final RankManager rankManager;

    public ChatListener(Main plugin, RankManager rankManager) {
        this.plugin = plugin;
        this.rankManager = rankManager;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        if (plugin.isChatMuted() && !event.getPlayer().hasPermission("citybuild.chat.bypass")) {
            event.setCancelled(true);
            event.getPlayer().sendMessage("§c!!Der Chat ist aktuell deaktiviert!!");
            return;
        }

        String prefix = rankManager.getRankPrefix(event.getPlayer());
        String color = rankManager.getChatColor(event.getPlayer());
        event.setFormat(prefix + " §8| §7" + event.getPlayer().getName() + " §8» " + color + event.getMessage());
    }
}