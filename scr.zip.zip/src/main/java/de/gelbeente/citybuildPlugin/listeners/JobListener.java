package de.gelbeente.citybuildPlugin.listeners;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.JobManager;
import de.gelbeente.citybuildPlugin.manager.BoosterManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class JobListener implements Listener {

    private final Main plugin;

    public JobListener(Main plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        if (event.isCancelled()) return;
        Player player = event.getPlayer();
        JobManager.Job job = plugin.getJobManager().getJob(player);
        Material mat = event.getBlock().getType();
        
        boolean earned = false;

        // MINER: Steine und Erze
        if (job == JobManager.Job.MINER) {
            if (mat.name().contains("ORE") || mat == Material.STONE || mat == Material.DEEPSLATE || mat == Material.COBBLESTONE) {
                earned = true;
            }
        }
        // LUMBERJACK: Holz
        else if (job == JobManager.Job.LUMBERJACK) {
            if (mat.name().contains("LOG")) {
                earned = true;
            }
        }
        // DIGGER: Erde, Sand, Kies
        else if (job == JobManager.Job.DIGGER) {
            if (mat == Material.DIRT || mat == Material.GRASS_BLOCK || mat == Material.SAND || mat == Material.GRAVEL) {
                earned = true;
            }
        }

        if (earned) {
            // Belohnung: Geld + BattlePass XP
            double money = 0.5 + (Math.random() * 2.0); // Zwischen 0.5 und 2.5
            
            if (plugin.getBoosterManager().isActive(BoosterManager.BoosterType.MONEY)) {
                money *= 2.0; // Verdoppeln bei Booster
            }
            
            plugin.getEconomyManager().addMoney(player.getUniqueId(), money);
            
            // BattlePass XP geben
            plugin.getBattlePassManager().addXp(player, 1);
            
            // Actionbar Nachricht (optional)
            // player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText("§a+ " + String.format("%.2f", money) + "$ §8| §b+1 BP-XP"));
        }
    }
}