package de.gelbeente.citybuildPlugin.listeners;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.PerkManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class PerkListener implements Listener {

    private final Main plugin;

    public PerkListener(Main plugin) {
        this.plugin = plugin;
    }

    // Effekte beim Joinen und Laufen checken
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        // Performance: Nur checken wenn Block gewechselt
        if (event.getFrom().getBlockX() == event.getTo().getBlockX() &&
            event.getFrom().getBlockY() == event.getTo().getBlockY() &&
            event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;

        Player player = event.getPlayer();
        checkEffects(player);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        checkEffects(event.getPlayer());
    }

    private void checkEffects(Player player) {
        if (plugin.getPerkManager().hasPerk(player, PerkManager.Perk.SPEED)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 100, 0, false, false));
        }
        if (plugin.getPerkManager().hasPerk(player, PerkManager.Perk.HASTE)) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 100, 3, false, false));
        }
    }

    // Kein Hunger
    @EventHandler
    public void onHunger(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            if (plugin.getPerkManager().hasPerk(player, PerkManager.Perk.NO_HUNGER)) {
                event.setCancelled(true);
                player.setFoodLevel(20);
            }
        }
    }

    // Kein Fallschaden
    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player && event.getCause() == EntityDamageEvent.DamageCause.FALL) {
            Player player = (Player) event.getEntity();
            if (plugin.getPerkManager().hasPerk(player, PerkManager.Perk.NO_FALL)) {
                event.setCancelled(true);
            }
        }
    }

    // Keep XP
    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        if (plugin.getPerkManager().hasPerk(event.getEntity(), PerkManager.Perk.KEEP_XP)) {
            event.setKeepLevel(true);
            event.setDroppedExp(0);
        }
    }
}