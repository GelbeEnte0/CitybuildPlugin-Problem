package de.gelbeente.citybuildPlugin.listeners;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

public class ElevatorListener implements Listener {

    @EventHandler
    public void onJump(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        // Prüfen, ob der Spieler nach oben springt (Y-Wert steigt)
        if (event.getFrom().getY() < event.getTo().getY()) {
            Location loc = player.getLocation().clone().subtract(0, 1, 0); // Block unter den Füßen
            if (loc.getBlock().getType() == Material.IRON_BLOCK) {
                // Nach oben suchen
                for (int y = loc.getBlockY() + 2; y < 320; y++) {
                    Location target = loc.clone();
                    target.setY(y);
                    if (target.getBlock().getType() == Material.IRON_BLOCK) {
                        // Teleportieren
                        Location tpLoc = target.add(0.5, 1, 0.5);
                        tpLoc.setYaw(player.getLocation().getYaw());
                        tpLoc.setPitch(player.getLocation().getPitch());
                        player.teleport(tpLoc);
                        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1, 1);
                        break;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent event) {
        Player player = event.getPlayer();
        if (event.isSneaking()) { // Wenn er sich duckt
            Location loc = player.getLocation().clone().subtract(0, 1, 0);
            if (loc.getBlock().getType() == Material.IRON_BLOCK) {
                // Nach unten suchen
                for (int y = loc.getBlockY() - 2; y > -64; y--) {
                    Location target = loc.clone();
                    target.setY(y);
                    if (target.getBlock().getType() == Material.IRON_BLOCK) {
                        Location tpLoc = target.add(0.5, 1, 0.5);
                        tpLoc.setYaw(player.getLocation().getYaw());
                        tpLoc.setPitch(player.getLocation().getPitch());
                        player.teleport(tpLoc);
                        player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1, 1);
                        break;
                    }
                }
            }
        }
    }
}