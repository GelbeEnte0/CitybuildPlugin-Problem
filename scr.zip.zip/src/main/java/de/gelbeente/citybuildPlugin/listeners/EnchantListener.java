package de.gelbeente.citybuildPlugin.listeners;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.EnchantManager;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Set;

public class EnchantListener implements Listener {

    private final Main plugin;
    private final EnchantManager enchantManager;
    // Verhindert StackOverflow bei Timber und Endlos-Loops bei 3x3
    private final Set<Player> activeBreakers = new HashSet<>();

    public EnchantListener(Main plugin, EnchantManager enchantManager) {
        this.plugin = plugin;
        this.enchantManager = enchantManager;
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        if (event.isCancelled()) return;
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();

        if (activeBreakers.contains(player)) return; // Schutz vor Rekursion

        // --- TIMBER (Baumfäller) ---
        if (enchantManager.hasEnchant(item, EnchantManager.TIMBER) && isLog(event.getBlock().getType())) {
            activeBreakers.add(player);
            breakTree(event.getBlock(), item, 0);
            activeBreakers.remove(player);
        }

        // --- BLAST (3x3) & GIANT (5x5) ---
        boolean is3x3 = enchantManager.hasEnchant(item, EnchantManager.BLAST_3x3);
        boolean is5x5 = enchantManager.hasEnchant(item, EnchantManager.GIANT_5x5);

        if (is3x3 || is5x5) {
            int radius = is5x5 ? 2 : 1; // Radius 1 = 3x3, Radius 2 = 5x5
            activeBreakers.add(player);
            breakArea(event.getBlock(), item, player, radius);
            activeBreakers.remove(player);
        }
    }

    private void breakTree(Block block, ItemStack tool, int count) {
        if (count > 200) return; // Limit, damit der Server nicht crasht
        if (!isLog(block.getType())) return;

        block.breakNaturally(tool);

        // Rekursiv Nachbarn prüfen
        for (BlockFace face : BlockFace.values()) {
            if (face == BlockFace.SELF) continue;
            Block relative = block.getRelative(face);
            if (isLog(relative.getType())) {
                breakTree(relative, tool, count + 1);
            }
        }
    }

    private void breakArea(Block center, ItemStack tool, Player player, int radius) {
        // Wir gehen von x-radius bis x+radius und y-radius bis y+radius
        // Z wird meist ignoriert oder abhängig von Blickrichtung gemacht.
        // Hier machen wir einfach eine Kugel/Würfel um den Block für Einfachheit
        
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x == 0 && y == 0 && z == 0) continue; // Der Hauptblock ist schon weg

                    Block target = center.getRelative(x, y, z);
                    if (target.getType() != Material.AIR && target.getType() != Material.BEDROCK) {
                        // Plot-Schutz Check müsste hier hin (über PlotManager)
                        // Da wir keine API haben, simulieren wir Events oder brechen einfach
                        // WICHTIG: InvSee/Plot Check hier einfügen wenn nötig
                        
                        if (isMineable(target.getType())) {
                           target.breakNaturally(tool);
                        }
                    }
                }
            }
        }
    }

    private boolean isLog(Material mat) {
        return mat.name().contains("_LOG") || mat.name().contains("_WOOD") || mat.name().contains("_STEM");
    }
    
    private boolean isMineable(Material mat) {
        return mat == Material.STONE || mat == Material.COBBLESTONE || mat == Material.DIRT || 
               mat == Material.GRASS_BLOCK || mat == Material.GRAVEL || mat == Material.SAND ||
               mat == Material.NETHERRACK || mat == Material.END_STONE || mat.name().contains("_ORE") || 
               mat.name().contains("DEEPSLATE");
    }
}