package de.gelbeente.citybuildPlugin.listeners;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;

public class AdminPanelListener implements Listener {
    
    // Wir brauchen Zugriff auf die Main Klasse für die Mute-Variable. 
    // Da dieser Listener in der Main registriert wird als `new AdminPanelListener()`,
    // müssen wir das Plugin hier eigentlich nicht übergeben, aber wir holen es uns 
    // über JavaPlugin.getPlugin oder ändern den Konstruktor. 
    // Der einfachste Weg in deinem Setup (ohne Main-Konstruktor überall zu ändern):
    private final Main plugin = (Main) Bukkit.getPluginManager().getPlugin("CitybuildPlugin");

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        // Prüfen ob es unser Admin-Panel ist
        if (!event.getView().getTitle().equals("§c§lAdmin-Panel")) {
            return;
        }

        // Interaktion im GUI verbieten (Items rausnehmen)
        event.setCancelled(true);

        if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) {
            return;
        }

        Player player = (Player) event.getWhoClicked();
        Material mat = event.getCurrentItem().getType();

        switch (mat) {
            case GRASS_BLOCK: // Survival
                player.setGameMode(GameMode.SURVIVAL);
                player.sendMessage("§aGamemode auf Survival gesetzt.");
                player.closeInventory();
                break;
            case DIAMOND_PICKAXE: // Creative
                player.setGameMode(GameMode.CREATIVE);
                player.sendMessage("§aGamemode auf Kreativ gesetzt.");
                player.closeInventory();
                break;
            case ENDER_EYE: // Spectator
                player.setGameMode(GameMode.SPECTATOR);
                player.sendMessage("§aGamemode auf Zuschauer gesetzt.");
                player.closeInventory();
                break;
            case SUNFLOWER: // Tag
                player.getWorld().setTime(1000);
                player.sendMessage("§eZeit auf Tag gesetzt.");
                break;
            case WATER_BUCKET: // Sonne
                player.getWorld().setStorm(false);
                player.getWorld().setThundering(false);
                player.sendMessage("§bWetter auf klar gesetzt.");
                break;
            case REDSTONE_BLOCK: // ChatClear
                for (int i = 0; i < 100; i++) Bukkit.broadcastMessage(" ");
                Bukkit.broadcastMessage("§cDer Chat wurde von " + player.getName() + " geleert.");
                player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
                break;
            case BARRIER: // Global Mute
                boolean newState = !plugin.isChatMuted();
                plugin.setChatMuted(newState);
                Bukkit.broadcastMessage(newState ? "§4§lACHTUNG §8» §cDer Chat wurde deaktiviert!" : "§a§lINFO §8» §aDer Chat wurde wieder aktiviert.");
                player.closeInventory();
                break;
            case BONE: // Kill Mobs
                {
                    int count = 0;
                    for (Entity entity : player.getWorld().getEntities()) {
                        // Wir löschen nur Lebewesen, aber KEINE Spieler
                        if (entity instanceof LivingEntity && !(entity instanceof Player)) {
                            entity.remove();
                            count++;
                        }
                    }
                    player.sendMessage("§cEs wurden " + count + " Entities entfernt.");
                    player.closeInventory();
                }
                break;
            case FEATHER: // Flugmodus
                boolean canFly = player.getAllowFlight();
                player.setAllowFlight(!canFly); // Umschalten
                player.sendMessage(canFly ? "§cFlugmodus deaktiviert." : "§aFlugmodus aktiviert.");
                player.closeInventory();
                break;
        }
    }
}