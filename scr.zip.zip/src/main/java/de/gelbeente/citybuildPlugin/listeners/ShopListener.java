package de.gelbeente.citybuildPlugin.listeners;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.ShopManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class ShopListener implements Listener {

    private final Main plugin;

    public ShopListener(Main plugin, ShopManager shopManager) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getView().getTitle() == null) return;
        String title = event.getView().getTitle();
        Player player = (Player) event.getWhoClicked();
        ItemStack clicked = event.getCurrentItem();

        if (clicked == null || !title.contains("Shop")) return;
        event.setCancelled(true); // Shop-Items nicht rausnehmbar

        // Navigation Hauptmenü -> Erze
        if (title.equals(plugin.getShopManager().MAIN_TITLE)) {
            if (clicked.getType() == Material.DIAMOND_ORE) {
                plugin.getShopManager().openOreCategory(player);
            }
        }

        // Navigation Erze -> Mengen-Auswahl
        else if (title.equals(plugin.getShopManager().ORE_TITLE)) {
            if (clicked.getType() == Material.BARRIER) {
                plugin.getShopManager().openGui(player);
                return;
            }
            // Preis aus der Beschreibung (Lore) ziehen oder festlegen
            double price = 100.0; // Hier müsste deine Preis-Logik hin
            plugin.getShopManager().openAmountSelect(player, clicked.getType(), price);
        }

        // KAUF-LOGIK (Mengenauswahl)
        else if (title.startsWith("§8Kaufen:")) {
            String[] parts = title.split(":");
            Material mat = Material.valueOf(parts[1]);
            double singlePrice = Double.parseDouble(parts[2]);
            int amount = 1;

            if (clicked.getItemMeta().getDisplayName().contains("16x")) amount = 16;
            if (clicked.getItemMeta().getDisplayName().contains("64x")) amount = 64;

            double total = singlePrice * amount;

            // HIER: Check Geld (Vault oder dein System)
            // if (plugin.getEco().has(player, total)) { ... }

            player.getInventory().addItem(new ItemStack(mat, amount));
            player.sendMessage("§aDu hast " + amount + "x " + mat.name() + " für " + total + "$ gekauft!");
            player.closeInventory();
        }
    }
}