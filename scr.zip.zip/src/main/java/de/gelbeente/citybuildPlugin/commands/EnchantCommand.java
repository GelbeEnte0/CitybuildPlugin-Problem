package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.EnchantManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class EnchantCommand implements CommandExecutor {

    private final Main plugin;

    public EnchantCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (!player.hasPermission("citybuild.enchant.admin")) {
            player.sendMessage("§cKeine Rechte.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§cNutze: /adminverzauberung <timber|3x3|5x5>");
            return true;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        if (args[0].equalsIgnoreCase("timber")) plugin.getEnchantManager().addEnchant(item, EnchantManager.TIMBER);
        else if (args[0].equalsIgnoreCase("3x3")) plugin.getEnchantManager().addEnchant(item, EnchantManager.BLAST_3x3);
        else if (args[0].equalsIgnoreCase("5x5")) plugin.getEnchantManager().addEnchant(item, EnchantManager.GIANT_5x5);
        
        player.sendMessage("§aEnchantment hinzugefügt!");
        return true;
    }
}