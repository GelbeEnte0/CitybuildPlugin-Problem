package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Random;

public class CoinflipCommand implements CommandExecutor {

    private final Main plugin;
    private final Random random = new Random();

    public CoinflipCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length != 1) {
            player.sendMessage("§cVerwendung: /cf <Einsatz>");
            return true;
        }

        double amount;
        try {
            amount = Double.parseDouble(args[0]);
        } catch (NumberFormatException e) {
            player.sendMessage("§cBitte gib eine gültige Zahl ein.");
            return true;
        }

        if (amount <= 0) {
            player.sendMessage("§cDer Einsatz muss positiv sein.");
            return true;
        }

        if (plugin.getEconomyManager().getBalance(player.getUniqueId()) < amount) {
            player.sendMessage("§cDu hast nicht genug Geld.");
            return true;
        }

        if (random.nextBoolean()) {
            plugin.getEconomyManager().addMoney(player.getUniqueId(), amount);
            player.sendMessage("§a§lGEWONNEN! §eDu hast §6" + (amount * 2) + "$ §eerhalten!");
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 1);
        } else {
            plugin.getEconomyManager().removeMoney(player.getUniqueId(), amount);
            player.sendMessage("§c§lVERLOREN! §7Du hast §c" + amount + "$ §7verloren.");
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1, 1);
        }

        return true;
    }
}