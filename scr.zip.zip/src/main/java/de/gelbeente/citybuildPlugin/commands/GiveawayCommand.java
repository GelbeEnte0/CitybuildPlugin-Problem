package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GiveawayCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("citybuild.creator.giveaway")) {
            sender.sendMessage("§cDas dürfen nur Creator und Teammitglieder!");
            return true;
        }

        List<Player> onlinePlayers = new ArrayList<>(Bukkit.getOnlinePlayers());

        if (sender instanceof Player) {
            onlinePlayers.remove((Player) sender);
        }

        if (onlinePlayers.isEmpty()) {
            sender.sendMessage("§cEs sind nicht genügend Spieler online.");
            return true;
        }

        Random random = new Random();
        Player winner = onlinePlayers.get(random.nextInt(onlinePlayers.size()));

        Bukkit.broadcastMessage("§8§m---------------------------------------");
        Bukkit.broadcastMessage("§6§lVERLOSUNG §8» §7Gewinner ist: §a§l" + winner.getName());
        Bukkit.broadcastMessage("§8§m---------------------------------------");

        return true;
    }
}