package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class SignAllCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (!player.hasPermission("citybuild.sign.all")) {
            player.sendMessage("§cDas ist ein Creator/Premium Feature!");
            return true;
        }

        String text = String.join(" ", args);
        if (text.isEmpty()) text = "§7Signiert";

        String date = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
        int count = 0;

        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.getType() != Material.AIR) {
                ItemMeta meta = item.getItemMeta();
                if (meta != null) {
                    meta.setLore(Arrays.asList(
                            "§7Signiert von §e" + player.getName(),
                            "§7am §e" + date,
                            "§f" + text
                    ));
                    item.setItemMeta(meta);
                    count++;
                }
            }
        }

        player.sendMessage("§aEs wurden §e" + count + " §aItems in deinem Inventar signiert!");
        return true;
    }
}