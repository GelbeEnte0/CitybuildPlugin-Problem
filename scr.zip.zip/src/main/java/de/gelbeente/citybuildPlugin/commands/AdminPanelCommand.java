package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

public class AdminPanelCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cDieser Befehl ist nur für Spieler.");
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("citybuild.adminpanel")) {
            player.sendMessage("§cDazu hast du keine Rechte.");
            return true;
        }

        Inventory gui = Bukkit.createInventory(null, 27, "§c§lAdmin-Panel");

        gui.setItem(10, createItem(Material.GRASS_BLOCK, "§aSurvival", "§7Klicke für Gamemode 0"));
        gui.setItem(11, createItem(Material.DIAMOND_PICKAXE, "§bKreativ", "§7Klicke für Gamemode 1"));
        gui.setItem(12, createItem(Material.ENDER_EYE, "§3Zuschauer", "§7Klicke für Gamemode 3"));
        gui.setItem(14, createItem(Material.SUNFLOWER, "§eTag", "§7Setzt die Zeit auf Tag"));
        gui.setItem(15, createItem(Material.WATER_BUCKET, "§9Sonne", "§7Deaktiviert Regen"));
        gui.setItem(16, createItem(Material.REDSTONE_BLOCK, "§cChat leeren", "§7Löscht den Chat für alle"));
        gui.setItem(17, createItem(Material.BARRIER, "§4Global Mute", "§7Sperrt/Entsperrt den Chat"));
        gui.setItem(22, createItem(Material.BONE, "§4Kill Mobs", "§7Löscht alle Tiere/Monster (Anti-Lag)"));
        gui.setItem(24, createItem(Material.FEATHER, "§fFlugmodus", "§7Schaltet deinen Flugmodus um"));

        player.openInventory(gui);
        return true;
    }

    private ItemStack createItem(Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(Arrays.asList(lore));
            item.setItemMeta(meta);
        }
        return item;
    }
}