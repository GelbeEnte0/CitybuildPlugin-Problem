package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

public class RepairCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("citybuild.repair")) {
            player.sendMessage("§cDas ist ein Premium-Feature!");
            return true;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        ItemMeta meta = item.getItemMeta();

        // Prüfen, ob das Item überhaupt kaputt gehen kann (Schwert vs. Stein)
        if (meta instanceof Damageable) {
            Damageable damageable = (Damageable) meta;
            damageable.setDamage(0); // Schaden auf 0 setzen
            item.setItemMeta(meta); // Meta zurück auf das Item speichern
            
            player.sendMessage("§aDein Item wurde repariert.");
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_USE, 1, 1);
        } else {
            player.sendMessage("§cDu hältst kein reparierbares Item in der Hand.");
        }

        return true;
    }
}