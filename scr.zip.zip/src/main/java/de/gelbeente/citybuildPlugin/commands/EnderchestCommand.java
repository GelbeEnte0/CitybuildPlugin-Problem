package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EnderchestCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cNur für Spieler.");
            return true;
        }

        Player player = (Player) sender;

        // Fall 1: /ec (Eigenes Inventar)
        if (args.length == 0) {
            if (!player.hasPermission("citybuild.enderchest")) {
                player.sendMessage("§cDas ist ein Premium-Feature.");
                return true;
            }
            player.openInventory(player.getEnderChest());
            player.sendMessage("§aDu hast deine Enderkiste geöffnet.");
            return true;
        }

        // Fall 2: /ec <Spieler> (Admin Feature)
        if (!player.hasPermission("citybuild.enderchest.see")) {
            player.sendMessage("§cDazu hast du keine Rechte.");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);

        if (target == null) {
            player.sendMessage("§cDer Spieler ist nicht online.");
            return true;
        }

        player.openInventory(target.getEnderChest());
        player.sendMessage("§aDu hast die Enderkiste von §e" + target.getName() + " §ageöffnet.");

        return true;
    }
}