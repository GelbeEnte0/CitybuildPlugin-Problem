package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.manager.EconomyManager;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CodeCommand implements CommandExecutor {

    private final EconomyManager economyManager;
    private final List<UUID> usedCodesSession = new ArrayList<>();

    public CodeCommand(EconomyManager economyManager) {
        this.economyManager = economyManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            return true;
        }
        Player player = (Player) sender;

        if (args.length == 0) {
            player.sendMessage("§cBitte gib einen Code ein. Beispiel: /code START");
            return true;
        }

        String code = args[0];

        if (code.equalsIgnoreCase("START")) {
            if (usedCodesSession.contains(player.getUniqueId())) {
                player.sendMessage("§cDu hast in dieser Sitzung bereits einen Code eingelöst!");
                return true;
            }

            economyManager.addMoney(player.getUniqueId(), 1000);
            player.sendMessage("§aCode eingelöst! Du hast §e1000 Münzen §aerhalten.");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
            usedCodesSession.add(player.getUniqueId());

        } else if (code.equalsIgnoreCase("YOUTUBE")) {
            player.getInventory().addItem(new ItemStack(Material.DIAMOND, 5));
            player.sendMessage("§aCode eingelöst! Du hast §bItems §aerhalten.");
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
        } else {
            player.sendMessage("§cDieser Code ist ungültig.");
        }
        return true;
    }
}