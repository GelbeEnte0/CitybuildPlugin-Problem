package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.BoosterManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BoosterCommand implements CommandExecutor {

    private final Main plugin;

    public BoosterCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length < 2) {
            player.sendMessage("§e/booster <fly|money|drop> <minuten>");
            return true;
        }

        // Hier könnte man Gems abziehen
        if (!player.hasPermission("citybuild.booster.use")) {
            player.sendMessage("§cKeine Rechte oder zu wenig Gems.");
            return true;
        }

        try {
            BoosterManager.BoosterType type = BoosterManager.BoosterType.valueOf(args[0].toUpperCase());
            int mins = Integer.parseInt(args[1]);
            
            plugin.getBoosterManager().activateBooster(type, mins);
            
            Bukkit.broadcastMessage("§8§m--------------------------------");
            Bukkit.broadcastMessage("§6§lBOOSTER §8» §e" + player.getName() + " §7hat einen §b" + type.name() + "-Booster §7aktiviert!");
            Bukkit.broadcastMessage("§7Dauer: §e" + mins + " Minuten");
            Bukkit.broadcastMessage("§8§m--------------------------------");
            
        } catch (Exception e) {
            player.sendMessage("§cUngültiger Typ oder Zahl.");
        }
        return true;
    }
}