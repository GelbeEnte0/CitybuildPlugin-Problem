package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReportCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length < 2) {
            player.sendMessage("§cVerwendung: /report <Spieler> <Grund>");
            return true;
        }

        String targetName = args[0];
        StringBuilder reason = new StringBuilder();
        for (int i = 1; i < args.length; i++) reason.append(args[i]).append(" ");

        player.sendMessage("§aDein Report wurde gesendet.");

        for (Player all : Bukkit.getOnlinePlayers()) {
            if (all.hasPermission("citybuild.report.receive")) {
                all.sendMessage("§8§m--------------------------------");
                all.sendMessage("§c§lREPORT §8» §e" + player.getName() + " §7meldet §c" + targetName);
                all.sendMessage("§7Grund: §f" + reason.toString());
                all.playSound(all.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1, 1);
            }
        }
        return true;
    }
}