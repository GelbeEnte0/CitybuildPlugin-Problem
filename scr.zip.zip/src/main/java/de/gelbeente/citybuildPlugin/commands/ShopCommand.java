package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.ShopManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShopCommand implements CommandExecutor {
    private final ShopManager shopManager;

    public ShopCommand(Main plugin, ShopManager shopManager) {
        this.shopManager = shopManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (sender instanceof Player) {
            shopManager.openShop((Player) sender);
        }
        return true;
    }
}