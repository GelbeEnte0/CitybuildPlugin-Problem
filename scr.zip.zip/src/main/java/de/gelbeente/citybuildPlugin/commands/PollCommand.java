package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class PollCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("citybuild.creator.poll")) {
            sender.sendMessage("§cDas dürfen nur Creator und Teammitglieder!");
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage("§cVerwendung: /poll <Frage>");
            return true;
        }

        StringBuilder question = new StringBuilder();
        for (String arg : args) {
            question.append(arg).append(" ");
        }

        Bukkit.broadcastMessage("§8§m---------------------------------------");
        Bukkit.broadcastMessage("§b§lUMFRAGE §8» §f" + question.toString());
        Bukkit.broadcastMessage("§8» §7Stimme ab mit §aJa §7oder §cNein");
        Bukkit.broadcastMessage("§8§m---------------------------------------");

        return true;
    }
}