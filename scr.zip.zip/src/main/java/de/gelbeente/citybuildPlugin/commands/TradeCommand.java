package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.listeners.TradeListener;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TradeCommand implements CommandExecutor {

    private final Main plugin;

    public TradeCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length != 1) {
            player.sendMessage("§cNutze: /trade <Spieler>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);
        if (target == null || target.equals(player)) {
            player.sendMessage("§cSpieler nicht gefunden.");
            return true;
        }

        // Prüfen ob Invite vorliegt
        Player requester = plugin.getTradeManager().getRequestSender(player);
        if (requester != null && requester.equals(target)) {
            // Trade starten
            plugin.getTradeManager().removeRequest(player);
            TradeListener.openTradeGui(player, target);
            player.sendMessage("§aTrade gestartet!");
            target.sendMessage("§aTrade gestartet!");
        } else {
            plugin.getTradeManager().sendRequest(player, target);
            player.sendMessage("§aAnfrage gesendet an " + target.getName());
            target.sendMessage("§aTrade-Anfrage von " + player.getName() + " erhalten! Nutze /trade " + player.getName());
        }
        return true;
    }
}