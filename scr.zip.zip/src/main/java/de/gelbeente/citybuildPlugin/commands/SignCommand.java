package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SignCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (player.getInventory().getItemInMainHand().getType() == Material.AIR) {
            player.sendMessage("§cBitte halte ein Item in der Hand.");
            return true;
        }

        String text = String.join(" ", args);
        if (text.isEmpty()) text = "§7Signiert";

        ItemStack item = player.getInventory().getItemInMainHand();
        ItemMeta meta = item.getItemMeta();
        String date = new SimpleDateFormat("dd.MM.yyyy").format(new Date());
        
        meta.setLore(Arrays.asList(
            "§7Signiert von §e" + player.getName(), 
            "§7am §e" + date,
            "§f" + text
        ));
        item.setItemMeta(meta);
        player.sendMessage("§aItem erfolgreich signiert!");
        return true;
    }
}