package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class InvseeCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cDieser Befehl ist nur für Spieler.");
            return true;
        }

        Player player = (Player) sender;

        if (!player.hasPermission("citybuild.invsee")) {
            player.sendMessage("§cDazu hast du keine Rechte.");
            return true;
        }

        if (args.length != 1) {
            player.sendMessage("§cVerwendung: /invsee <Spieler>");
            return true;
        }

        Player target = Bukkit.getPlayer(args[0]);

        if (target == null) {
            player.sendMessage("§cDer Spieler ist nicht online (InvSee geht nur bei Online-Spielern).");
            return true;
        }

        // Öffnet das Inventar des Ziels
        player.openInventory(target.getInventory());
        player.sendMessage("§aDu hast das Inventar von §e" + target.getName() + " §ageöffnet.");

        return true;
    }
}