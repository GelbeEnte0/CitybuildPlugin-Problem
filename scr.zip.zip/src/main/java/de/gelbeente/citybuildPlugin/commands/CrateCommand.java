package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CrateCommand implements CommandExecutor {

    private final Main plugin;

    public CrateCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Admin Befehl: /crate give <Spieler|all> [Menge]
        if (args.length >= 2 && args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("citybuild.crate.admin")) {
                sender.sendMessage("§cDazu hast du keine Rechte.");
                return true;
            }

            int amount = 1;
            if (args.length >= 3) {
                try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException ignored) {}
            }

            // Check für "all" oder "*"
            if (args[1].equalsIgnoreCase("all") || args[1].equalsIgnoreCase("*")) {
                for (Player all : Bukkit.getOnlinePlayers()) {
                    plugin.getCrateManager().addKeys(all.getUniqueId(), amount);
                    all.sendMessage("§aDu hast §e" + amount + "x §6Crate Key(s) §aerhalten!");
                    all.playSound(all.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
                }
                sender.sendMessage("§aDu hast an alle Spieler " + amount + " Schlüssel vergeben.");
                return true;
            }

            Player target = Bukkit.getPlayer(args[1]);
            if (target != null) {
                plugin.getCrateManager().addKeys(target.getUniqueId(), amount);
                sender.sendMessage("§a" + amount + " Schlüssel gegeben an " + target.getName());
                target.sendMessage("§aDu hast §e" + amount + "x §6Crate Key(s) §aerhalten!");
                target.playSound(target.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
            } else {
                sender.sendMessage("§cSpieler nicht gefunden.");
            }
            return true;
        }

        if (sender instanceof Player) {
            Player player = (Player) sender;
            
            if (args.length > 0 && args[0].equalsIgnoreCase("open")) {
                plugin.getCrateManager().openCrate(player);
                return true;
            }

            int keys = plugin.getCrateManager().getKeys(player.getUniqueId());
            player.sendMessage("§8§m--------------------------------");
            player.sendMessage("§6§lCRATE SYSTEM");
            player.sendMessage("§7Deine Keys: §e" + keys);
            player.sendMessage(" ");
            player.sendMessage("§7Nutze §e/crate open §7um eine Kiste zu öffnen.");
            player.sendMessage("§8§m--------------------------------");
        }
        return true;
    }
}