package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.JobManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class JobsCommand implements CommandExecutor {

    private final Main plugin;

    public JobsCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length == 0) {
            player.sendMessage("§eDein Job: §f" + plugin.getJobManager().getJob(player));
            player.sendMessage("§7Wähle: /jobs join <miner|lumberjack|digger>");
            return true;
        }

        if (args[0].equalsIgnoreCase("join") && args.length == 2) {
            try {
                JobManager.Job job = JobManager.Job.valueOf(args[1].toUpperCase());
                plugin.getJobManager().setJob(player, job);
                player.sendMessage("§aDu bist nun " + job.name());
            } catch (IllegalArgumentException e) { player.sendMessage("§cUnbekannter Job."); }
        }
        return true;
    }
}