package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClanCommand implements CommandExecutor {

    private final Main plugin;

    public ClanCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length == 0) {
            player.sendMessage("§e/clan create <Name>");
            player.sendMessage("§e/clan invite <Spieler>");
            player.sendMessage("§e/clan join");
            player.sendMessage("§e/clan leave");
            player.sendMessage("§e/clan delete");
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("create")) {
            if (args.length < 2) return false;
            if (plugin.getClanManager().getClan(player) != null) {
                player.sendMessage("§cDu bist schon in einem Clan.");
                return true;
            }
            if (plugin.getClanManager().exists(args[1])) {
                player.sendMessage("§cName vergeben.");
                return true;
            }
            plugin.getClanManager().createClan(player, args[1]);
            player.sendMessage("§aClan " + args[1] + " erstellt!");
        } 
        else if (sub.equals("invite")) {
            if (args.length < 2) return false;
            String clan = plugin.getClanManager().getClan(player);
            if (clan == null || !plugin.getClanManager().isOwner(player, clan)) {
                player.sendMessage("§cNur für Clan-Owner.");
                return true;
            }
            Player target = Bukkit.getPlayer(args[1]);
            if (target != null) {
                plugin.getClanManager().invitePlayer(target, clan);
                player.sendMessage("§aEingeladen.");
                target.sendMessage("§aDu wurdest in den Clan " + clan + " eingeladen. Nutze /clan join");
            }
        }
        else if (sub.equals("join")) {
            if (plugin.getClanManager().hasInvite(player)) {
                plugin.getClanManager().acceptInvite(player);
                player.sendMessage("§aDu bist dem Clan beigetreten!");
            } else {
                player.sendMessage("§cDu hast keine Einladung.");
            }
        }
        else if (sub.equals("leave")) {
            plugin.getClanManager().leaveClan(player);
            player.sendMessage("§cClan verlassen.");
        }
        else if (sub.equals("delete")) {
             String clan = plugin.getClanManager().getClan(player);
             if (clan != null && plugin.getClanManager().isOwner(player, clan)) {
                 plugin.getClanManager().deleteClan(clan);
                 player.sendMessage("§cClan aufgelöst.");
             }
        }
        return true;
    }
}