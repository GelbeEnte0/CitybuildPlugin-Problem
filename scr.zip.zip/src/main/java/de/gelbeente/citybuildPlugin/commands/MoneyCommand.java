package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MoneyCommand implements CommandExecutor {

    private final Main plugin;

    public MoneyCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length == 0) {
            double balance = plugin.getEconomyManager().getBalance(player.getUniqueId());
            player.sendMessage("§aDein Kontostand: §e" + String.format("%.2f", balance) + "$");
        } else if (args.length == 3 && args[0].equalsIgnoreCase("pay")) {
            Player target = Bukkit.getPlayer(args[1]);
            double amount = Double.parseDouble(args[2]);
            if (target != null) {
                plugin.getEconomyManager().removeMoney(player.getUniqueId(), amount);
                plugin.getEconomyManager().addMoney(target.getUniqueId(), amount);
                player.sendMessage("§aDu hast §e" + amount + "$ §aan " + target.getName() + " gesendet.");
                target.sendMessage("§aDu hast §e" + amount + "$ §avon " + player.getName() + " erhalten.");
            }
        }
        return true;
    }
}