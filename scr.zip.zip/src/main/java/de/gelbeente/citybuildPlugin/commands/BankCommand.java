package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class BankCommand implements CommandExecutor {
    
    private final Main plugin;

    public BankCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        sender.sendMessage("§eDas Bank-System ist noch in Arbeit.");
        return true;
    }
}