package de.gelbeente.citybuildPlugin.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WorkbenchCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("§cNur für Spieler.");
            return true;
        }

        Player player = (Player) sender;
        
        // Öffnet das Crafting-Inventar (null = keine echte Werkbank in der Nähe nötig)
        player.openWorkbench(null, true);
        
        return true;
    }
}