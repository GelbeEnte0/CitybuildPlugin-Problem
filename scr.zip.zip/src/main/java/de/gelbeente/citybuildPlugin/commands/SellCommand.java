package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.SellManager;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class SellCommand implements CommandExecutor {

    private final Main plugin;
    private final SellManager sellManager;

    public SellCommand(Main plugin, SellManager sellManager) {
        this.plugin = plugin;
        this.sellManager = sellManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (!player.hasPermission("citybuild.sell.use")) {
            player.sendMessage("§cDazu hast du keine Rechte.");
            return true;
        }

        ItemStack item = player.getInventory().getItemInMainHand();

        if (item.getType() == Material.AIR) {
            player.sendMessage("§cDu musst ein Item in der Hand halten.");
            return true;
        }

        double pricePerItem = sellManager.getPrice(item.getType());

        if (pricePerItem <= 0) {
            player.sendMessage("§cDieses Item kann nicht verkauft werden.");
            return true;
        }

        int amount = item.getAmount();
        double total = pricePerItem * amount;

        player.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        plugin.getEconomyManager().addMoney(player.getUniqueId(), total);

        player.sendMessage("§aVerkauft: §f" + amount + "x " + item.getType().name());

        // Spezielle Nachricht bei Börsen-Einfluss
        if (plugin.getMarketManager().getCurrentHypeMaterial() == item.getType()) {
            player.sendMessage("§6§lBÖRSEN-DEAL! §eDu hast §6" + String.format("%.2f", total) + "$ §eerhalten!");
        } else {
            player.sendMessage("§aDu hast §e" + String.format("%.2f", total) + "$ §aerhalten.");
        }

        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1, 1);
        return true;
    }
}