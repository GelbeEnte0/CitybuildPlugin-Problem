package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VanishCommand implements CommandExecutor {
    private final Main plugin;

    public VanishCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;
        
        // Einfache Vanish Logik (Unsichtbarkeitseffekt)
        if (player.isInvisible()) {
            player.setInvisible(false);
            player.sendMessage("§cVanish deaktiviert.");
            for(Player all : Bukkit.getOnlinePlayers()) all.showPlayer(plugin, player);
        } else {
            player.setInvisible(true); // Macht nur unsichtbar, versteckt nicht in Tab (einfache Version)
            player.sendMessage("§aVanish aktiviert.");
        }
        return true;
    }
}