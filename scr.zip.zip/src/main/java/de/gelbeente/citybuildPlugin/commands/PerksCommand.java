package de.gelbeente.citybuildPlugin.commands;

import de.gelbeente.citybuildPlugin.Main;
import de.gelbeente.citybuildPlugin.manager.PerkManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;

public class PerksCommand implements CommandExecutor, Listener {

    private final Main plugin;

    public PerksCommand(Main plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;
        openGui(player);
        return true;
    }

    private void openGui(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, "§d§lPerk Shop");

        int slot = 11;
        for (PerkManager.Perk perk : PerkManager.Perk.values()) {
            boolean has = plugin.getPerkManager().hasPerk(player, perk);
            ItemStack item = new ItemStack(has ? Material.LIME_DYE : Material.GRAY_DYE);
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(perk.displayName);
            meta.setLore(Arrays.asList(
                    "§7Status: " + (has ? "§aGekauft" : "§cNicht gekauft"),
                    "§7Kosten: §b" + perk.cost + " Gems",
                    " ",
                    has ? "§7Bereits aktiv." : "§eKlicke zum Kaufen!"
            ));
            item.setItemMeta(meta);
            inv.setItem(slot, item);
            slot++;
        }

        player.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().equals("§d§lPerk Shop")) return;
        event.setCancelled(true);
        if (event.getCurrentItem() == null) return;

        if (!(event.getWhoClicked() instanceof Player)) return;
        Player player = (Player) event.getWhoClicked();
        
        if (!event.getCurrentItem().hasItemMeta()) return;
        String name = event.getCurrentItem().getItemMeta().getDisplayName();

        for (PerkManager.Perk perk : PerkManager.Perk.values()) {
            if (perk.displayName.equals(name)) {
                if (plugin.getPerkManager().hasPerk(player, perk)) {
                    player.sendMessage("§cDu besitzt dieses Perk bereits!");
                    player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1, 1);
                } else {
                    // Kaufen
                    long gems = plugin.getEconomyManager().getGems(player.getUniqueId());
                    if (gems >= perk.cost) {
                        plugin.getEconomyManager().removeGems(player.getUniqueId(), perk.cost);
                        plugin.getPerkManager().addPerk(player, perk);
                        player.sendMessage("§aDu hast das Perk " + perk.displayName + " §agekauft!");
                        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, 1);
                        player.closeInventory();
                    } else {
                        player.sendMessage("§cDu hast nicht genug Gems! Du brauchst " + perk.cost + ".");
                        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_NO, 1, 1);
                    }
                }
                break;
            }
        }
    }
}